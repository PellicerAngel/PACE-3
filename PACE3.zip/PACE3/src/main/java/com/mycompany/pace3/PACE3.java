
package com.mycompany.pace3;

import com.mycompany.HibernateUtil;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.query.Query;
import utils.*;


public class PACE3 {

    public static void main(String[] args) {
        int opcio = 0;

        do {
            System.out.println("Selecciona quina opcio vols: ");
            System.out.println("1- Crear");
            System.out.println("2- Llegir");
            System.out.println("3- Eliminar");
            System.out.println("4- Actualitzar");
            System.out.println("5- Eixir");
            opcio = Utilitats.leerEnteroC("");

            switch (opcio) {
                case 1 ->
                    crear();
                case 2 ->
                    llegir();
                case 3 ->
                    eliminar();
                case 4 ->
                    actualitzar();
                case 5 ->
                    System.out.println("Gracies per gastar la nostra aplicacio");
                default ->
                    System.out.println("Introduix una de les opcions disponibles");
            }
        } while (opcio != 5);
    }

    private static void crear() {
        try (Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
            laSesion.getTransaction().begin();

            System.out.println("De quina forma vols crear");
            System.out.println("1- Normal");
            System.out.println("2- Recursiva");
            int opcioCrear = Utilitats.leerEnteroC("");

            switch (opcioCrear) {
                case 1 -> {
                    System.out.println("Que vols crear");
                    System.out.println("1- Jugador");
                    System.out.println("2- Dessarrollador");
                    System.out.println("3- VideoJoc");
                    System.out.println("4- Garantia");
                    System.out.println("5- Eixir");
                    int opcio = Utilitats.leerEnteroC("");
                    switch (opcio) {
                        case 1 -> {
                            String nom_j = Utilitats.leerTextoG("Nom de Jugador: ");
                            String correu = Utilitats.leerTextoG("Correu de Jugador: ");

                            Jugador j = new Jugador(nom_j, correu);

                            laSesion.persist(j);
                            System.out.println(j);
                            break;
                        }
                        case 2 -> {
                            String nom_d = Utilitats.leerTextoG("Nom de Dessarrollador: ");
                            String pais = Utilitats.leerTextoG("Pais del Dessarrollador: ");
                            String id_joc = Utilitats.leerTextoG("Id del joc creat: ");

                            VideoJoc joc = laSesion.get(VideoJoc.class, id_joc);

                            Dessarrollador d = new Dessarrollador(nom_d, pais, joc);

                            laSesion.persist(d);
                            System.out.println(d);
                            break;
                        }
                        case 3 -> {
                            String titul = Utilitats.leerTextoG("Titul de VideoJoc: ");
                            String genere = Utilitats.leerTextoG("Genere del VideoJoc: ");
                            int preu = Utilitats.leerEnteroC("Preu del VideoJoc");

                            VideoJoc v = new VideoJoc(titul, genere, preu);

                            laSesion.persist(v);
                            System.out.println(v);
                            break;
                        }
                        case 4 -> {
                            String valida = Utilitats.leerTextoG("La garantia esta valida (true/false): ");
                            String fecha = Utilitats.leerTextoG("Fecha de la Garantia (dd/MM/yyyy): ");

                            Garantia g = new Garantia(valida, fecha);

                            laSesion.persist(g);
                            System.out.println(g);
                            break;
                        }
                        case 5 ->
                            System.out.println("Ixint de l'opcio crear");

                        default ->
                            System.out.println("Introduix una de les opcions disponibles");
                    }
                }
                case 2 -> {
                    System.out.println("Que vols crear");
                    System.out.println("1- Jugador");
                    System.out.println("2- Dessarrollador");
                    System.out.println("3- VideoJoc");
                    System.out.println("4- Garantia");
                    System.out.println("5- Eixir");
                    int opcio = Utilitats.leerEnteroC("");
                    switch (opcio) {
                        case 1 -> {
                            String nom_j = Utilitats.leerTextoG("Nom de Jugador: ");
                            String correu = Utilitats.leerTextoG("Correu de Jugador: ");
                            Jugador j = new Jugador(nom_j, correu);
                            laSesion.persist(j);
                            break;
                        }
                        case 2 -> {
                            String nom_d = Utilitats.leerTextoG("Nom de Dessarrollador: ");
                            String pais = Utilitats.leerTextoG("Pais del Dessarrollador: ");
                            String id_joc = Utilitats.leerTextoG("Pais del Dessarrollador: ");

                            VideoJoc joc = laSesion.get(VideoJoc.class, id_joc);

                            Dessarrollador d = new Dessarrollador(nom_d, pais, joc);
                            laSesion.persist(d);
                            break;
                        }
                        case 3 -> {
                            String titul = Utilitats.leerTextoG("Titul de VideoJoc: ");
                            String genere = Utilitats.leerTextoG("Genere del VideoJoc: ");
                            int preu = Utilitats.leerEnteroC("Preu del VideoJoc");
                            VideoJoc v = new VideoJoc(titul, genere, preu);
                            laSesion.persist(v);
                            break;
                        }
                        case 4 -> {
                            String valida = Utilitats.leerTextoG("La garantia esta valida (true/false): ");
                            String fecha = Utilitats.leerTextoG("Fecha de la Garantia (dd/MM/yyyy): ");
                            Garantia g = new Garantia(valida, fecha);
                            laSesion.persist(g);
                            break;
                        }
                        case 5 ->
                            System.out.println("Ixint de l'opcio crear");
                            
                        default ->
                            System.out.println("Introduix una de les opcions disponibles");

                    }
                }
                default ->
                    System.out.println("No has seleccionat una opcio valida");
            }

            laSesion.getTransaction().commit();
            laSesion.close();

        }
    }

    private static void llegir() {
        try (Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
            laSesion.getTransaction().begin();

            System.out.println("De quina forma vols mostrar");
            System.out.println("1- Normal");
            System.out.println("2- Recursiva");
            int opcioMostrar = Utilitats.leerEnteroC("");

            switch (opcioMostrar) {
                case 1: {
                    System.out.println("Que vols mostrar");
                    System.out.println("1- Jugador");
                    System.out.println("2- Dessarrollador");
                    System.out.println("3- VideoJoc");
                    System.out.println("4- Garantia");
                    System.out.println("5- Eixir");
                    int opcio = Utilitats.leerEnteroC("");
                    switch (opcio) {
                        case 1:
                            Query<Jugador> juga = laSesion.createQuery("from Jugador");
                            List<Jugador> jugadors = juga.list();
                            for (Jugador jugador : jugadors) {
                                System.out.println(jugador);
                            }
                            break;
                        case 2:
                            Query<Dessarrollador> desa = laSesion.createQuery("from Dessarrollador");
                            List<Dessarrollador> dessarrolladors = desa.list();
                            for (Dessarrollador dessarrollador : dessarrolladors) {
                                System.out.println(dessarrollador);
                            }
                            break;
                        case 3:
                            Query<VideoJoc> joc = laSesion.createQuery("from VideoJoc");
                            List<VideoJoc> videojocs = joc.list();
                            for (VideoJoc videojoc : videojocs) {
                                System.out.println(videojoc);
                            }
                            break;
                        case 4:
                            Query<Garantia> garan = laSesion.createQuery("from Garantia");
                            List<Garantia> garanties = garan.list();
                            for (Garantia garantia : garanties) {
                                System.out.println(garantia);
                            }
                            break;
                        case 5:
                            System.out.println("Ixint de l'opcio crear");
                            break;
                        default:
                            System.out.println("Introduix una de les opcions disponibles");

                    }
                    break;
                }
                case 2: {
                    System.out.println("Que vols mostrar");
                    System.out.println("1- Jugador");
                    System.out.println("2- Dessarrollador");
                    System.out.println("3- VideoJoc");
                    System.out.println("4- Garantia");
                    System.out.println("5- Eixir");
                    int opcio = Utilitats.leerEnteroC("");
                    switch (opcio) {
                        case 1:
                            Query<Jugador> juga = laSesion.createQuery("from Jugador");
                            List<Jugador> jugadors = juga.list();
                            for (Jugador jugador : jugadors) {
                                System.out.println(jugador);
                            }
                        case 2:
                            Query<Dessarrollador> desa = laSesion.createQuery("from Dessarrollador");
                            List<Dessarrollador> dessarrolladors = desa.list();
                            for (Dessarrollador dessarrollador : dessarrolladors) {
                                System.out.println(dessarrollador);
                            }
                        case 3:
                            Query<VideoJoc> joc = laSesion.createQuery("from VideoJoc");
                            List<VideoJoc> videojocs = joc.list();
                            for (VideoJoc videojoc : videojocs) {
                                System.out.println(videojoc);
                            }
                        case 4:
                            Query<Garantia> garan = laSesion.createQuery("from Garantia");
                            List<Garantia> garanties = garan.list();
                            for (Garantia garantia : garanties) {
                                System.out.println(garantia);
                            }
                        case 5:
                            System.out.println("Ixint de l'opcio crear");
                            break;
                        default:
                            System.out.println("Introduix una de les opcions disponibles");

                    }
                    break;
                }
                default:
                    System.out.println("No has seleccionat una opcio valida");
                    break;
            }

            laSesion.getTransaction().commit();
            laSesion.close();

        }
    }

    private static void actualitzar() {

//                int dnip = 1234;
//                Persona a = laSesion.get(Persona.class, dnip);
//                a.setEdat(6);
//                laSesion.update(a);
//                System.out.println(a);
        try (Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
            laSesion.getTransaction().begin();

            System.out.println("Què vols actualitzar?");
            System.out.println("1- Jugador");
            System.out.println("2- Dessarrollador");
            System.out.println("3- VideoJoc");
            System.out.println("4- Garantia");
            System.out.println("5- Eixir");

            int opcio = Utilitats.leerEnteroC("");

            switch (opcio) {
                case 1 -> {
                    Query<Jugador> juga = laSesion.createQuery("from Jugador");
                    List<Jugador> jugadors = juga.list();
                    for (Jugador jugador : jugadors) {
                        System.out.println(jugador);
                    }
                    int id_jugador = Utilitats.leerEnteroC("Dime l'ID del Jugador a modificar:");
                    Jugador j = laSesion.get(Jugador.class, id_jugador);

                    System.out.println("Jugador actual: " + j);

                    String confirmacio = Utilitats.leerTextoG("Vols modificar el nom del Jugador? (si/no): ");
                    if (confirmacio.equalsIgnoreCase("si")) {
                        String nom_j = Utilitats.leerTextoG("Nou nom de Jugador: ");
                        j.setNom(nom_j);
                    }

                    confirmacio = Utilitats.leerTextoG("Vols modificar el correu del Jugador? (si/no): ");
                    if (confirmacio.equalsIgnoreCase("si")) {
                        String correu = Utilitats.leerTextoG("Nou correu de Jugador: ");
                        j.setCorreu(correu);
                    }

                    laSesion.update(j);
                    System.out.println("Jugador actualitzat: " + j);
                    break;
                }

                case 2 -> {
                    Query<Dessarrollador> desa = laSesion.createQuery("from Dessarrollador");
                    List<Dessarrollador> dessarrolladors = desa.list();
                    for (Dessarrollador dessarrollador : dessarrolladors) {
                        System.out.println(dessarrollador);
                    }
                    int id_dessarrollador = Utilitats.leerEnteroC("Dime l'ID del Dessarrollador a modificar:");
                    Dessarrollador d = laSesion.get(Dessarrollador.class, id_dessarrollador);

                    System.out.println("Dessarrollador actual: " + d);

                    String confirmacio2 = Utilitats.leerTextoG("Vols modificar el nom del Dessarrollador? (si/no): ");
                    if (confirmacio2.equalsIgnoreCase("si")) {
                        String nom_d = Utilitats.leerTextoG("Nou nom de Dessarrollador: ");
                        d.setNom(nom_d);
                    }

                    confirmacio2 = Utilitats.leerTextoG("Vols modificar el pais del Dessarrollador? (si/no): ");
                    if (confirmacio2.equalsIgnoreCase("si")) {
                        String pais = Utilitats.leerTextoG("Nou pais del Dessarrollador: ");
                        d.setPais(pais);
                    }

                    laSesion.update(d);
                    System.out.println("Dessarrollador actualitzat: " + d);
                    break;
                }

                case 3 -> {
                    Query<VideoJoc> joc = laSesion.createQuery("from VideoJoc");
                    List<VideoJoc> videojocs = joc.list();
                    for (VideoJoc videojoc : videojocs) {
                        System.out.println(videojoc);
                    }
                    int id_VideoJoc = Utilitats.leerEnteroC("Dime l'ID del VideoJoc a modificar:");
                    VideoJoc v = laSesion.get(VideoJoc.class, id_VideoJoc);

                    System.out.println("VideoJoc actual: " + v);

                    String confirmacio3 = Utilitats.leerTextoG("Vols modificar el títol del VideoJoc? (si/no): ");
                    if (confirmacio3.equalsIgnoreCase("si")) {
                        String titul = Utilitats.leerTextoG("Nou títol de VideoJoc: ");
                        v.setTitul(titul);
                    }

                    confirmacio3 = Utilitats.leerTextoG("Vols modificar el gènere del VideoJoc? (si/no): ");
                    if (confirmacio3.equalsIgnoreCase("si")) {
                        String genere = Utilitats.leerTextoG("Nou gènere del VideoJoc: ");
                        v.setGenere(genere);
                    }

                    laSesion.update(v);
                    System.out.println("VideoJoc actualitzat: " + v);
                    break;
                }

                case 4 -> {
                    Query<Garantia> garan = laSesion.createQuery("from Garantia");
                    List<Garantia> garanties = garan.list();
                    for (Garantia garantia : garanties) {
                        System.out.println(garantia);
                    }
                    int id_garantia = Utilitats.leerEnteroC("Dime l'ID de la Garantia a modificar:");
                    Garantia g = laSesion.get(Garantia.class, id_garantia);

                    System.out.println("Garantia actual: " + g);

                    String confirmacio4 = Utilitats.leerTextoG("Vols modificar la validesa de la Garantia? (si/no): ");
                    if (confirmacio4.equalsIgnoreCase("si")) {
                        String valida = Utilitats.leerTextoG("Nou estat de la Garantia (true/false): ");
                        g.setValida(valida);
                    }

                    confirmacio4 = Utilitats.leerTextoG("Vols modificar la data de la Garantia? (si/no): ");
                    if (confirmacio4.equalsIgnoreCase("si")) {
                        String fecha = Utilitats.leerTextoG("Nova data de la Garantia (dd/MM/yyyy): ");
                        g.setFecha(fecha);
                    }

                    laSesion.update(g);
                    System.out.println("Garantia actualitzada: " + g);
                    break;
                }

                case 5 ->
                    System.out.println("Ixint de l'opció actualitzar");

                default ->
                    System.out.println("Introduïx una de les opcions disponibles");
            }

            laSesion.getTransaction().commit();
            laSesion.close();

        }
    }

    private static void eliminar() {
        try (Session laSesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
            laSesion.getTransaction().begin();

            System.out.println("Que vols eliminar");
            System.out.println("1- Jugador");
            System.out.println("2- Dessarrollador");
            System.out.println("3- VideoJoc");
            System.out.println("4- Garantia");
            System.out.println("5- Eixir");

            int opcio = Utilitats.leerEnteroC("");

            switch (opcio) {
                case 1:
                    int id_jugador = Utilitats.leerEnteroC("Disme l'ID del Jugador a eliminar:");
                    Jugador jugador = laSesion.get(Jugador.class, id_jugador);

                    if (jugador != null) {
                        if (!jugador.getElsJocs().isEmpty()) {
                            for (VideoJoc joc : jugador.getElsJocs()) {
                                joc.getElsJugadors().remove(jugador);
                                laSesion.update(joc);
                            }
                            jugador.getElsJocs().clear();
                        }

                        laSesion.remove(jugador);
                        System.out.println("Jugador eliminat correctament.");
                    } else {
                        System.out.println("Jugador amb ID " + id_jugador + " no trobat.");
                    }
                    break;
                case 2:
                    int id_dessarrollador = Utilitats.leerEnteroC("Disme l'ID del Jugador a eliminar:");
                    Dessarrollador dessarrollador = laSesion.get(Dessarrollador.class, id_dessarrollador);

                    if (dessarrollador != null) {
                        VideoJoc videojoc = dessarrollador.getJoc();
                        if (videojoc != null) {
                            videojoc.getElsDessarrolladors().remove(dessarrollador);
                            dessarrollador.setJoc(null);
                            laSesion.update(videojoc);
                        }

                        laSesion.remove(dessarrollador);
                        System.out.println("Dessarrollador eliminat correctament.");
                    } else {
                        System.out.println("Dessarrollador amb ID " + id_dessarrollador + " no trobat.");
                    }
                    break;
                case 3:
                    int id_videoJoc = Utilitats.leerEnteroC("Disme l'ID del Jugador a eliminar:");
                    VideoJoc videojoc = laSesion.get(VideoJoc.class, id_videoJoc);

                    if (videojoc != null) {
                        if (!videojoc.getElsJugadors().isEmpty()) {
                            for (Jugador juga : videojoc.getElsJugadors()) {
                                juga.getElsJocs().remove(videojoc);
                            }
                            videojoc.getElsJugadors().clear();
                        }

                        // Pas 3: Desvincula les relacions amb els desenvolupadors
                        if (!videojoc.getElsDessarrolladors().isEmpty()) {
                            for (Dessarrollador dessa : videojoc.getElsDessarrolladors()) {
                                dessa.setJoc(null);
                            }
                            videojoc.getElsDessarrolladors().clear();
                        }

                        if (videojoc.getGarantiajoc() != null) {
                            Garantia garantia = videojoc.getGarantiajoc();
                            garantia.setVideojoc(null);
                            videojoc.setGarantiajoc(null);
                            laSesion.update(garantia);
                        }

                        laSesion.remove(videojoc);
                        System.out.println("Videojoc eliminat correctament.");
                    } else {
                        System.out.println("Videojoc amb ID " + id_videoJoc + " no trobat.");
                    }
                    break;
                case 4:
                    int id_garantia = Utilitats.leerEnteroC("Disme l'ID del Jugador a eliminar:");
                    Garantia garantia = laSesion.get(Garantia.class, id_garantia);

                    if (garantia != null) {
                        if (garantia.getVideojoc() != null) {
                            VideoJoc video = garantia.getVideojoc();
                            video.setGarantiajoc(null); 
                            garantia.setVideojoc(null);   
                            laSesion.update(video);  
                        }

                        laSesion.remove(garantia);
                        System.out.println("Garantia eliminada correctament.");
                    } else {
                        System.out.println("Garantia amb ID " + id_garantia + " no trobada.");
                    }
                    break;
                default:
                    System.out.println("Introduix una de les opcions disponibles");

            }
            laSesion.getTransaction().commit();
            laSesion.close();
        }
    }
}
