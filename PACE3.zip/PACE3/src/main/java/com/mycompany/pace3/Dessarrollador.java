package com.mycompany.pace3;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
@Table(name = "Dessarrollador")
public class Dessarrollador implements Serializable {

    static final long serialVersionUID = 17L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_dessarrollador;

    @Column
    private String nom;

    @Column
    private String pais;

    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(
            name = "id_videojoc",
            foreignKey = @ForeignKey(name = "FK_DES_JOC")
    )
    @EqualsAndHashCode.Exclude // Evita bucles infinits en equals/hashCode
    @ToString.Exclude          // Evita bucles infinits en toString()
    private VideoJoc joc;

    public Dessarrollador(String nom, String pais, VideoJoc joc) {
        this.nom = nom;
        this.pais = pais;
        this.joc = joc;
    }
}
