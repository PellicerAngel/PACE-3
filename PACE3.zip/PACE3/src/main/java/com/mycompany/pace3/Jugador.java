package com.mycompany.pace3;

import java.util.List;
import jakarta.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
@Table(name="Jugador")
public class Jugador implements Serializable {

    static final long serialVersionUID = 17L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_jugador;

    @Column
    private String nom;

    @Column
    private String correu;

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @JoinTable(name = "Compra",
            joinColumns = {
                @JoinColumn(
                        name = "id_jugador",
                        foreignKey = @ForeignKey(name = "FK_JUGA_JOC"))},
            inverseJoinColumns = {
                @JoinColumn(
                        name = "id_videojoc",
                        foreignKey = @ForeignKey(name = "FK_JOC_JUGA"))})
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private List<VideoJoc> elsJocs = new ArrayList<>();

    public void AfegirJoc(VideoJoc v) {
        if(!elsJocs.contains(v)){
            elsJocs.add(v);
            v.AfegirJugador(this);
        }
    }

    public Jugador(String nom, String correu) {
        this.nom = nom;
        this.correu = correu;
    }

}
