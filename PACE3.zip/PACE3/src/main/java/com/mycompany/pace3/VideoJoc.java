package com.mycompany.pace3;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
@Table(name = "VideoJoc")
public class VideoJoc implements Serializable {

    static final long serialVersionUID = 17L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_videojoc;

    @Column
    private String titul;

    @Column
    private String genere;

    @Column
    private int preu;

    @OneToOne(mappedBy = "videojoc")
    private Garantia garantiajoc;

    @OneToMany(mappedBy = "joc", cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private List<Dessarrollador> elsDessarrolladors;

    public void AfegirDessarrollador(Dessarrollador d) {
        elsDessarrolladors.add(d);
        d.setJoc(this);
    }

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY, mappedBy = "elsJocs")
    @EqualsAndHashCode.Exclude
    @ToString.Exclude
    private List<Jugador> elsJugadors = new ArrayList<>();

    public void AfegirJugador(Jugador j) {
        if (!elsJugadors.contains(j)) {
            elsJugadors.add(j);
            j.AfegirJoc(this);
        }

    }

    public VideoJoc(String titul, String genere, int preu) {
        this.titul = titul;
        this.genere = genere;
        this.preu = preu;
    }

}
