package com.mycompany.pace3;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@NoArgsConstructor
@Table(name = "Garantia")
public class Garantia implements Serializable {

    static final long serialVersionUID = 17L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_garantia;

    @Column
    private String valida;

    @Column
    private String fecha;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(
            name = "id_videojoc",
            referencedColumnName = "id_videojoc",
            unique = true,
            foreignKey = @ForeignKey(name = "FK_GAR_JOC")
    )
    @EqualsAndHashCode.Exclude // Evita bucles infinits en equals/hashCode
    @ToString.Exclude          // Evita bucles infinits en toString()
    private VideoJoc videojoc;

    public Garantia(String valida, String fecha) {
        this.valida = valida;
        this.fecha = fecha;
    }
}
